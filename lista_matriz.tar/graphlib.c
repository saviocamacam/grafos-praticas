#include "graphlib.h"

MyGraph * newGraph() {
	MyGraph * graph = (MyGraph*) malloc (sizeof(MyGraph));
	graph->first = NULL;
	graph->last = NULL;
	graph->quantityCell = 0;
	return graph;
}

void toPointerNULL(Vertex * pointer) {
	pointer->next = NULL;
	pointer->over = NULL;
	pointer->under = NULL;
}

_Bool isExists(MyGraph * graph, int point) {
	_Bool true=1, false=0;
	Vertex * aux = graph->first;
	while(aux != NULL) {
		if(aux->data == point) {
			return true;
		}
		aux = aux->under;
	}
	return false;
}

_Bool addVertex(MyGraph * graph, int point) {
	_Bool true=1, false=0;
	Vertex * vertex = (Vertex*) malloc (sizeof(Vertex));
	vertex->data = point;
	toPointerNULL(vertex);
	if(graph->first == NULL) {
		graph->first = vertex;
		graph->last = vertex;
	}
	else if(isExists(graph, point)) return false;
	else if(graph->first != NULL) {
		vertex->over = graph->last;
		graph->last->under = vertex;
		graph->last = vertex;
	}
	graph->quantityCell = graph->quantityCell + 1;
	return true;
}

Vertex * findVertex(MyGraph * graph, int pointA) {
	Vertex * point = NULL;
	Vertex * aux = graph->first;
	while(aux != NULL) {
		if(aux->data == pointA) {
			return aux;
		}
		aux = aux->under;
	}
	return point;
}

_Bool deleteVertex(MyGraph * graph, Vertex * point) {
	_Bool true=1, false=0;
	int pointVertex = point->data;
	if(point->over == NULL) {
		point->under->over = NULL;
		graph->first = point->under;
		}
	else if(point->under == NULL) {
		point->over->under = NULL;
		graph->last = point->over;
	}
	else {
		point->over->under = point->under;
		point->under->over = point->over;
	}
	Vertex * aux = graph->first;
	Vertex * aux2;
	while(aux != NULL) {
		printf("aux->data%d ", aux->data);
		aux2 = aux->next;
		while(aux2 != NULL) {
			printf("aux2->data%d\n", aux2->data);
			if(aux2->data == point->data) {
				if(aux2->next == NULL) {
					aux2->prev->next = NULL;
				}
				else {
					aux2->prev->next = aux2->next;
					aux2->next->prev = aux2->prev;
				}
			}
			aux2 = aux2->next;
		}
		aux = aux->under;
	}
	return true;
}

_Bool addEdge(MyGraph * graph, ItemType pointA, ItemType pointB) {
	_Bool false = 0, true = 1;
	//cria os dois novos dados de arestas
	addVertex(graph, pointA);
	addVertex(graph, pointB);

	Vertex * vertexB = (Vertex*) malloc (sizeof(Vertex));
	vertexB->data = pointB;
	toPointerNULL(vertexB);

	Vertex * aux = graph->first;
	while(aux != NULL) {
		if(aux->data == pointA) {
			Vertex * aux2 = aux->next;
			if(aux2 == NULL) {
				aux->next = vertexB;
				vertexB->prev = aux;
				return true;
			}
			while(aux2 != NULL) {
				if(aux2->data == pointB) return false;
				aux2 = aux2->next;
			}
			vertexB->next = aux->next;
			vertexB->next->prev = vertexB;
			vertexB->prev = aux;
			aux->next = vertexB;
			return true;
		}
		aux = aux->under;
	}
	return false;
}

Edge * findEdge(MyGraph * graph, int pointA, int pointB) {
	Edge * edgeAB = NULL;
	Vertex * aux = graph->first;
	Vertex * aux2 = NULL;

	while(aux != NULL) {
		if(aux->data == pointA) {
			Vertex * aux2 = aux->next;
			while(aux2 != NULL) {
				if(aux2->data == pointB) {
					edgeAB = (Edge*) malloc (sizeof(Edge));
					edgeAB->pointA = aux;
					edgeAB->pointB = aux2;
				}
				aux2 = aux2->next;
			}
		}
		aux = aux->under;
	}
	return edgeAB;
}

_Bool deleteEdge(MyGraph * graph, Edge * edgeAB) {
	_Bool true = 1;
	if(edgeAB->pointB->next == NULL) {
		edgeAB->pointB->prev->next = NULL;
	}
	else {
		edgeAB->pointB->prev->next = edgeAB->pointB->next;
		edgeAB->pointB->next->prev = edgeAB->pointB->prev;
	}
	free(edgeAB->pointB);
	return true;
}

void getMatrix(MyGraph * graph, int ***matrix) {
	int **localMatrix = (int**) calloc (graph->quantityCell, sizeof(int*));
	int i, j;
	Vertex * aux = graph->first;
	Vertex * aux2 = graph->first;
	Edge * edgeAB = NULL;
	for (i=0 ; i<=graph->quantityCell ; i++) {
		localMatrix[i] = (int*) calloc (graph->quantityCell, sizeof(int));
	}
	for (i=0 ; i<graph->quantityCell ; i++) {
		for(j=0 ; j<graph->quantityCell ; j++) {
			edgeAB = findEdge(graph, aux->data, aux2->data);
			if(edgeAB != NULL) {
				localMatrix[i][j] = 1;
			}
			if(aux2->under != NULL) {
				aux2 = aux2->under;
			}
			printf(" %d ", localMatrix[i][j]);
		}
		aux2 = graph->first;
		aux = aux->under;
		printf("\n");
	}
	*matrix = localMatrix;
}

void printList(MyGraph * graph) {
	Vertex * auxV = graph->first;
	Vertex * auxH;
	while(auxV != NULL) {
		printf("%d > ", auxV->data);
		auxH = auxV->next;
		while(auxH != NULL) {
			printf("%d > ", auxH->data);
			auxH = auxH->next;
		}
		auxV = auxV->under;
		printf("\n");
	}
	printf("\n");
}
