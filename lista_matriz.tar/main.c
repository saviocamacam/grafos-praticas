#include <stdio.h>
#include <stdlib.h>
#include "graphlib.h"

int main(int argc, char *argv[]) {
	int **matrizAdjacencias;
	int menuOption;
	int verticeOrigem;
	int verticeDestino;
	int retorno;

	MyGraph * graph = (MyGraph*) newGraph();
	do{
		printf(">(1) ADICIONAR VERTICE\n");
		printf(">(2) BUSCAR VERTICE\n");
		printf(">(3) REMOVER VERTICE\n");
		printf(">(4) ADICIONAR ARESTA\n");
		printf(">(5) BUSCAR ARESTA\n");
		printf(">(6) REMOVER ARESTA\n");
		printf("(7) BUSCA EM LARGURA\n");
		printf(">(8) APAGAR GRAFO\n");
		printf("(9) GERAR MATRIZ\n");
		printf(">(10) IMPRIMIR LISTA\n");
		printf(">(11) SAIR\n");
		printf("OPCAO: ");
		printf("\n");
		/*addVertex(graph, 1);
		addVertex(graph, 3);
		addEdge(graph, 3, 2);
		addEdge(graph, 2, 5);
		addEdge(graph, 5, 1);
		addEdge(graph, 1, 4);
		addEdge(graph, 1, 5);
		printList(graph);*/


		scanf("%d", &menuOption);
		if(menuOption == 1) {
			printf("\nVALOR: ");
			scanf("%d", &verticeOrigem);
			retorno = addVertex(graph, verticeOrigem);
			if(retorno == 1){
				printf("VERTICE ADICIONADO!\n");
        printList(graph);
			}else printf("ERRO!\n");
		}
		if(menuOption == 2) {
			printf("\nVALOR: ");
			scanf("%d", &verticeOrigem);
			Vertex * point = findVertex(graph, verticeOrigem);
			if(point != NULL) {
				printf("\nESSE VERTICE EXISTE!");
				printf("\nVertice: %d\n", point->data);
			}
			else printf("\nESSE VERTICE NAO EXISTE!\n");
		}
		if(menuOption == 3) {
			printf("\nVALOR: ");
			scanf("%d", &verticeOrigem);
			Vertex * point = findVertex(graph, verticeOrigem);
			if(point != NULL) {
				retorno = deleteVertex(graph, point);
				printf("retorno delete: %d\n", retorno);
				if(retorno == 1) {
					printf ("Deu certo!\n");
				}
				printList(graph);
			}
			else printf("\nESSE VERTICE NAO EXISTE!\n");
		}
		if(menuOption == 4) {
			printf("\nORIGEM: ");
			scanf("%d", &verticeOrigem);
			printf("\nDESTINO: ");
			scanf("%d", &verticeDestino);
			retorno = addEdge(graph, verticeOrigem, verticeDestino);
			if (retorno == 1) {
				printf ("\nARESTA ADICIONADA!\n");
				printList(graph);
			}else printf ("ERRO!\n");
		}
		if(menuOption == 5) {
      printf("\nORIGEM: ");
      scanf("%d", &verticeOrigem);
      printf("\nDESTINO: ");
			scanf("%d", &verticeDestino);
      Edge * edgeAB = findEdge(graph, verticeOrigem, verticeDestino);
      if(edgeAB != NULL) {
        printf("\nA ARESTA EXISTE!\n");
        printf("A: %d", edgeAB->pointA->data);
        printf("\nB: %d", edgeAB->pointB->data);
      }
			else printf("\nESSA ARESTA NAO EXISTE!\n");
    }

		if(menuOption == 6) {
      printf("\nORIGEM: ");
      scanf("%d", &verticeOrigem);
      printf("\nDESTINO: ");
			scanf("%d", &verticeDestino);
      Edge * edgeAB = findEdge(graph, verticeOrigem, verticeDestino);
      if(edgeAB != NULL) {
				retorno = deleteEdge(graph, edgeAB);
				printf("retorno delete: %d\n", retorno);
				if(retorno == 1) {
					printf ("Deu certo!\n");
				}
				printList(graph);
      }
			else printf("\nESSA ARESTA NAO EXISTE!\n");
    }

		if(menuOption == 8) {
			free(graph);
			graph = (MyGraph*) newGraph();
			printf("\nGRAFO REINICIADO!\n");
		}
		if(menuOption == 9) {
			getMatrix(graph, &matrizAdjacencias);
		}
		if(menuOption == 10) {
			printList(graph);
		}
	} while(menuOption != 11);
	return 0;
}
